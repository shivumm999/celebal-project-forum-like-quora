<?php require_once("utility.php"); 
ob_start(); 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Discussion Forum</title>

<script type="text/javascript" src="script.js"></script>

    <link rel="stylesheet" href="../res/style.css" type="text/css" media="screen" />
    <!--[if IE 6]><link rel="stylesheet" href="res/style.ie6.css" type="text/css" media="screen" /><![endif]-->
    <!--[if IE 7]><link rel="stylesheet" href="res/style.ie7.css" type="text/css" media="screen" /><![endif]-->
    
</head>

<body>
<div id="art-page-background-simple-gradient">
    </div>
    <div id="art-page-background-glare">
        <div id="art-page-background-glare-image"></div>
    </div>
    <div id="art-main">
        <div class="art-Sheet">
            <div class="art-Sheet-tl"></div>
            <div class="art-Sheet-tr"></div>
            <div class="art-Sheet-bl"></div>
            <div class="art-Sheet-br"></div>
            <div class="art-Sheet-tc"></div>
            <div class="art-Sheet-bc"></div>
            <div class="art-Sheet-cl"></div>
            <div class="art-Sheet-cr"></div>
            <div class="art-Sheet-cc"></div>
            <div class="art-Sheet-body">
                <div class="art-Header">
                    <div class="art-Header-jpeg"></div>
                    <div class="art-Logo">
                        <h1 id="name-text" class="art-Logo-name"><a href="#">Technical Discussion Forum</a></h1>
                        <div id="slogan-text" class="art-Logo-text">Learn More</div>
                    </div>
                </div>
                <div class="art-nav">
                	<div class="l"></div>
                	<div class="r"></div>
                	<ul class="art-menu">
                		<li><a href="home.php" id="ahome"><span class="l"></span><span class="r"></span><span class="t">Home</span></a></li>
                		<li><a href="#" id="amanage"><span class="l"></span><span class="r"></span><span class="t">Manage</span></a>
                			<ul>
                				<li><a href="topic.php">Manage topic</a></li>
                				<li><a href="subtopic.php">Manage Subtopic</a></li>
                			</ul>
                		</li>
                		
                		<li><a href="messages.php"id="amessage"><span class="l"></span><span class="r"></span><span class="t">Messages</span></a>
                		                	
</ul>
                </div>
                <div class="art-contentLayout">
                    <div class="art-content">
                       </div>
                      </div>