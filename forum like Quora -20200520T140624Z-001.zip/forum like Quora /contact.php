<?php  require("header.php"); ?>
<script type="text/javascript">
	document.getElementById("acontact").className="active";
</script>


	<h1>Contact Us</h1>
    <table>
    
	
    <tr><td rowspan="4"></td><td>shubham singh</td><td>:</td><td>btech cs cloud 6th sem</td></tr>
    <tr><td rowspan="1">shivam sharma</td><td>:</td><td>btech cs cloud 6th sem</td></tr>
    <tr><td rowspan="1">sankalp khandelwal</td><td>:</td><td>btech cs cloud 6th sem</td></tr>
   <tr><td rowspan="1">saijal paliwal</td><td>:</td><td>btech cs cloud 6th sem</td></tr>
    </table>
    
<?php require("footer.php"); ?>