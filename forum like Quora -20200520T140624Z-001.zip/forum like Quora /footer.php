<div class="cleared"></div><div class="art-Footer">
                    <div class="art-Footer-inner">
                        
                        <div class="art-Footer-text">
                            <p>
                                <br><b>MADE BY :-</b></br>
                                <br>shubham singh</br>
                                <br>shivam sharma</br>
                                <br>sankalp khandelwal</br>
                                <br>saijal paliwal</br>
                            </p>
                        </div>
                    </div>
                    <div class="art-Footer-background"></div>
                </div>
            </div>
        </div>
           
</body>



</html>